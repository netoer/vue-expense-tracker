<template>
    <h1>Tu saldo es:</h1> 
    <h2>$400.00</h2>
</template>