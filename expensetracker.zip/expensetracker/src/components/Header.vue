<template>
    <h2>Expense tracker</h2>
</template>