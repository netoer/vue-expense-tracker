<template>
    <div class="inc-exp-container">
        <div>
            <h4>Ingresos</h4>
            <p id="money-plus" class="money plus">+$0.00</p>
        </div>
        <div>
            <h4>Gastos</h4>
            <p id="money-minus" class="money minus">-$0.00</p>
        </div>
    </div>
</template>